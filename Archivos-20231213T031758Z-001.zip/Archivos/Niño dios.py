from machine import Pin, PWM, Timer
from hcsr04 import HCSR04
from time import sleep
import time
import network
from umqtt.simple import MQTTClient



MQTT_BROKER = "broker.hivemq.com"
MQTT_USER = ""
MQTT_PASSWORD = ""
MQTT_CLIENT_ID = ""
MQTT_TOPIC = "utng/kacc/sensor"
MQTT_PORT = 1883

def conectar_wifi():
    print("Conectandose espere...", end="")
    sta_if = network.WLAN(network.STA_IF)
    sta_if.active(True)
    sta_if.connect('UTNG_Alumnos', '')
    while not sta_if.isconnected():
        print(".", end="")
        sleep(0.3)
    print("Conectando!!")
       
def abrir_ventana():
    servo.duty(180)  # Ángulo de apertura 
def cerrar_ventana():
    servo.duty(0)  # Ángulo de cierre


def llegada_mensaje(topic, msg):
    print(msg)
    if msg == b'2':
        # Mover el servo a 0 grados
        move_servo(0)
        # Esperar un momento antes de moverlo a 90 grados
        time.sleep(1)
        # Mover el servo a 90 grados
        move_servo(60)


 
# Configurar el pin del servo
servo_pin = Pin(13, Pin.OUT)
servo = PWM(servo_pin, freq=50)  # Frecuencia de 50Hz, puede ajustarse según las especificaciones de tu servo
    

    
    

def subscribir():
    client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER, MQTT_PORT, MQTT_USER, MQTT_PASSWORD, keepalive=0)
    client.set_callback(llegada_mensaje)
    client.connect()
    client.subscribe(MQTT_TOPIC)
    print("Conectado a %s, en el topico %s" % (MQTT_BROKER, MQTT_TOPIC))
    return client

    

#Asignasion de variables/pines :)
pin_servo = 13  # Puedes usar cualquier pin PWM disponible
servo = PWM(Pin(pin_servo), freq=50) 

#Leds y buzzer
led_pins = [15, 2, 4, 18, 19, 21]
buzzer_pin = 5
# Pin para los servos

#Sensor de proximidad
sensor = HCSR04(trigger_pin=25, echo_pin=26, echo_timeout_us=10000)
#Buzzer y leds al ritmo de la musica wuuu
leds = [Pin(pin, Pin.OUT) for pin in led_pins]
buzzer = PWM(Pin(buzzer_pin, Pin.OUT), freq=1000, duty=0)

# Melodía de Santa Claus en frecuencias
santa_claus_melody = [
    392, 329, 349, 392, 392,
    440, 493, 523, 523, 523,
    329, 349, 392, 392, 392,
    440, 392, 349, 349,
    329, 392, 261, 329,
    293, 349, 246,
    261
]

santa_claus_durations = [
    500, 250, 250, 250, 500,
    250, 250, 250, 250, 1000,
    250, 250, 500, 250, 500,
    250, 250, 250, 500,
    250, 250, 250, 250,
    250, 500, 250,
    1000
]

# Melodía de Jingle Bells en frecuencias
jingle_bells_melody = [
    659, 659, 659,
    659, 659, 659,
    659, 784, 523, 587,
    659,
    698, 698, 698, 698,
    698, 659, 659, 659, 659,
    659, 587, 587, 659,
    587, 784
]

jingle_bells_durations = [
    250, 250, 500,
    250, 250, 500,
    250, 250, 250, 250,
    1000,
    250, 250, 250, 250,
    250, 250, 250, 125, 125,
    250, 250, 250, 250,
    500, 250
]



def move_servo(angle):
    duty = int(((angle / 180) * 95) + 40)  # Convertir ángulo a ciclo de trabajo
    servo.duty(duty)
    time.sleep(1)

#reproduce la melodia
def play_melody(melody, durations):
    for i in range(len(melody)):
        note = melody[i]
        duration = durations[i]
        buzzer.freq(note)
        buzzer.duty(512)
        sleep(duration / 1000)
        buzzer.duty(0)
        for led in leds:
            led.value(1)
        sleep(0.1)
        for led in leds:
            led.value(0)


conectar_wifi()
client = subscribir()


while True:
    client.wait_msg()
    distance = sensor.distance_cm()  
    print('Distance:', distance, 'cm')
    if distance < 15:
        play_melody(jingle_bells_melody, jingle_bells_durations)
        sleep(1)  # Pausa de 1 segundo entre melodías
        play_melody(santa_claus_melody, santa_claus_durations)
    time.sleep(0.3)