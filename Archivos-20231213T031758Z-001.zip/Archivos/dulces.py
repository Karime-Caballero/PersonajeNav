from machine import Pin, PWM
from time import sleep
import network
from umqtt.simple import MQTTClient

MQTT_BROKER = "broker.hivemq.com"
MQTT_USER = ""
MQTT_PASSWORD = ""
MQTT_CLIENT_ID = ""
MQTT_TOPIC = "utng/kacc/sensor"
MQTT_PORT = 1883

def conectar_wifi():
    print("Conectandose espere...", end="")
    sta_if = network.WLAN(network.STA_IF)
    sta_if.active(True)
    sta_if.connect('enparis', '12345678')
    while not sta_if.isconnected():
        print(".", end="")
        sleep(0.3)
    print("Conectando!!")

def llegada_mensaje(topic, msg):
    print(msg)
    if msg == b'1':
        abrir_ventana()  # Abre el servo
    elif msg == b'0':
        cerrar_ventana()   # Cierra el servo

# Establece la frecuencia del servo (50Hz)
def abrir_ventana():
    servo.duty(70)  # Ángulo de apertura 
def cerrar_ventana():
    servo.duty(25)  # Ángulo de cierre 

def subscribir():
    client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER, MQTT_PORT, MQTT_USER, MQTT_PASSWORD, keepalive=0)
    client.set_callback(llegada_mensaje)
    client.connect()
    client.subscribe(MQTT_TOPIC)
    print("Conectado a %s, en el topico %s" % (MQTT_BROKER, MQTT_TOPIC))
    return client

# Configurar el pin del servo
servo_pin = Pin(27, Pin.OUT)
servo = PWM(servo_pin, freq=50)  # Frecuencia de 50Hz, puede ajustarse según las especificaciones de tu servo

conectar_wifi()
client = subscribir()

while True:
    client.wait_msg()